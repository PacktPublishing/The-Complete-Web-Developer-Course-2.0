<?php

    $link = mysqli_connect("localhost", "cl29-secretdi", "D-fnT^Hbz", "cl29-secretdi");
        
        if (mysqli_connect_error()) {
            
            die ("Database Connection Error");
            
        }

?>